package com.example.parking_system.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor @Data
public class API {

    private String msg;
    private Integer status;
}
